"""Small file-based checks: no Python -c quoting in Windows PowerShell."""
import struct
import sys
from pathlib import Path


def probe(mode):
    if mode == 'version':
        if sys.version_info < (3, 11) or struct.calcsize('P') != 8:
            print('Requires 64-bit Python 3.11 or newer')
            return 10
        print(sys.executable)
    elif mode == 'tk':
        try:
            import tkinter as tk
            import _tkinter
        except ImportError as error:
            print('Tkinter module missing: ' + str(error))
            return 11
        try:
            root = tk.Tk()
            root.withdraw()
            root.update_idletasks()
            root.destroy()
        except Exception as error:
            print('Tcl/Tk initialization failed: ' + str(error))
            return 12
        print('Tcl/Tk OK')
    elif mode == 'deps':
        try:
            import customtkinter
            from PIL import Image
            import yt_dlp
        except Exception as error:
            print('Dependency check failed: ' + str(error))
            return 13
        print('Dependencies OK')
    else:
        print('Unknown probe: ' + mode)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(probe(sys.argv[1] if len(sys.argv) == 2 else ''))
