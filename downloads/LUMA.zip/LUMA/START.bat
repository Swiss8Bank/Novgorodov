@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
if errorlevel 1 (
 echo.
 echo Не удалось запустить LUMA. Сообщение об ошибке показано выше.
 pause
 exit /b 1
)
endlocal
