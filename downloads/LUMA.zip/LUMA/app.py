"""LUMA — minimal graphite interface with emerald accents."""
import json
import os
from pathlib import Path
import queue
import sys
import tkinter as tk
from tkinter import filedialog
import customtkinter as ctk
from PIL import Image, ImageDraw
from controller import App as Controller, CONFIG
from core import QUALITIES, BROWSERS, CONNECTIONS

BG = '#090b0a'
CARD = '#131615'
FIELD = '#1b1f1d'
LINE = '#2a302d'
GREEN = '#37f58b'
TEXT = '#f3f6f4'
MUTED = '#939d97'
FONT = 'Segoe UI' if os.name == 'nt' else 'DejaVu Sans'
if sys.platform.startswith('linux'):
    from customtkinter.windows.widgets.core_rendering import DrawEngine
    DrawEngine.preferred_drawing_method = 'polygon_shapes'


class EntryValue:
    """Keep the native placeholder while exposing StringVar-style get/set."""
    def __init__(self, entry):
        self.entry = entry
    def get(self):
        return self.entry.get()
    def set(self, value):
        self.entry.delete(0, 'end')
        self.entry.insert(0, value)


class Progress(ctk.CTkProgressBar):
    def __setitem__(self, key, value):
        if key == 'value':
            self.set(float(value) / 100)


class App(Controller):
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.downloader = None
        self.closing = False
        self.last_progress = 0
        self.settings_window = None
        self.log_window = None
        self.proxy_visible = False
        root.title('LUMA — YouTube Downloader')
        root.geometry('940x960')
        root.minsize(750, 760)
        root.configure(fg_color=BG)
        root.protocol('WM_DELETE_WINDOW', self.close)
        saved = {}
        try:
            saved = json.loads(CONFIG.read_text(encoding='utf-8'))
            if not isinstance(saved, dict):
                saved = {}
        except (OSError, ValueError):
            pass
        self.url = tk.StringVar()
        self.folder = tk.StringVar(value=str(saved.get('folder', Path.home() / 'Downloads' / 'YouTube')))
        q = saved.get('quality', '1080')
        self.quality = tk.StringVar(value=q if q in QUALITIES else '1080')
        self.browser = tk.StringVar(value='Без cookies')
        self.cookies = tk.StringVar()
        self.proxy = tk.StringVar()
        connection_label=next((label for label,mode in CONNECTIONS.items() if mode==saved.get('connection','auto')),'Как в Windows')
        self.connection=tk.StringVar(value=connection_label)
        self.streams = tk.IntVar(value=8)
        self.status = tk.StringVar(value='Вставьте ссылку — остальное мы подготовили.')
        # Scroll keeps the primary action accessible on small screens and at 125% scaling.
        outer = ctk.CTkScrollableFrame(root, fg_color=BG, scrollbar_button_color='#242b27', scrollbar_button_hover_color='#3c4941')
        outer.pack(fill='both', expand=True)
        card = ctk.CTkFrame(outer, width=660, corner_radius=32, fg_color=CARD,
                            border_width=1, border_color=LINE)
        card.pack(padx=34, pady=(30, 24), fill='x')
        self.card = card
        top = ctk.CTkFrame(card, fg_color='transparent')
        top.pack(fill='x', padx=30, pady=(25, 5))
        ctk.CTkLabel(top, text='↓  L U M A', text_color=TEXT, font=(FONT, 14, 'bold')).pack(side='left')
        ctk.CTkLabel(top, text='YOUTUBE DOWNLOADER', text_color=MUTED, font=(FONT, 10)).pack(side='right')
        # Artwork is drawn locally, with no external fonts or network assets.
        art = Image.new('RGB', (700, 144), CARD)
        pix = art.load()
        import math
        for y in range(144):
            for x in range(700):
                glow = math.exp(-(((x-280)/160)**2 + ((y-70)/70)**2))
                pix[x, y] = (19+int(glow*2), 22+int(glow*14), 21+int(glow*7))
        draw = ImageDraw.Draw(art)
        for y in range(8, 144, 15):
            for x in range(10, 700, 15):
                draw.ellipse((x,y,x+1,y+1), fill='#29352e')
        for i in range(6):
            x=249+i*35
            draw.rounded_rectangle((x,13,x+25,17),radius=2,fill=GREEN if i==0 else '#3a4540')
        draw.rounded_rectangle((314,50,378,116),radius=12,fill='#242d28',outline='#425147',width=1)
        draw.rounded_rectangle((324,41,368,99),radius=6,fill='#dce8e0')
        draw.polygon([(340,55),(340,81),(358,68)],fill='#293c31')
        draw.rounded_rectangle((310,83,382,129),radius=12,fill='#1d3025',outline='#395d46')
        draw.line((346,92,346,116),fill=GREEN,width=3)
        draw.line((337,107,346,116,355,107),fill=GREEN,width=3)
        self.hero_image=ctk.CTkImage(light_image=art,dark_image=art,size=(700,144))
        ctk.CTkLabel(card,text='',image=self.hero_image).pack(pady=(6,0))
        ctk.CTkLabel(card,text='Любимые видео.\nВсегда с вами.',font=(FONT,34,'bold'),text_color=TEXT,justify='center').pack(pady=(6,7))
        ctk.CTkLabel(card,text='Одна ссылка. Нужное качество. Ничего лишнего.',font=(FONT,14),text_color=MUTED).pack(pady=(0,24))
        content = ctk.CTkFrame(card,fg_color='transparent')
        content.pack(fill='x',padx=34)
        ctk.CTkLabel(content,text='ССЫЛКА НА ВИДЕО',font=(FONT,10,'bold'),text_color=MUTED).pack(anchor='w',pady=(0,7))
        urlbox=ctk.CTkFrame(content,fg_color=FIELD,corner_radius=15,border_width=1,border_color=LINE)
        urlbox.pack(fill='x')
        self.url_entry=ctk.CTkEntry(urlbox,placeholder_text='https://youtube.com/watch?v=…',height=48,fg_color=FIELD,border_width=0,font=(FONT,14))
        self.url_entry.pack(side='left',fill='x',expand=True,padx=(13,3),pady=4)
        self.url=EntryValue(self.url_entry)
        ctk.CTkButton(urlbox,text='Вставить',width=88,height=34,corner_radius=10,fg_color='#29322c',hover_color='#354139',text_color='#c3d1c8',command=self.paste).pack(side='right',padx=9)
        qrow=ctk.CTkFrame(content,fg_color='transparent')
        qrow.pack(fill='x',pady=(20,8))
        ctk.CTkLabel(qrow,text='КАЧЕСТВО',font=(FONT,10,'bold'),text_color=MUTED).pack(side='left')
        ctk.CTkLabel(qrow,text='1080p — хороший баланс',font=(FONT,11),text_color=MUTED).pack(side='right')
        chips=ctk.CTkFrame(content,fg_color='transparent')
        chips.pack(fill='x')
        self.quality_buttons={}
        for i,(label,value) in enumerate([('720p','720'),('1080p','1080'),('1440p','1440'),('4K','2160'),('Лучшее','Максимальное')]):
            chips.columnconfigure(i,weight=1)
            b=ctk.CTkButton(chips,text=label,height=38,width=68,corner_radius=11,font=(FONT,12),command=lambda v=value:self.quality.set(v))
            b.grid(row=0,column=i,sticky='ew',padx=(0,7 if i<4 else 0))
            self.quality_buttons[value]=b
        self.quality.trace_add('write',lambda *_:self.paint_quality())
        self.paint_quality()
        self.option_row(content,'↳','Папка сохранения',self.folder,'Изменить',self.pick_folder)
        self.access_caption=tk.StringVar(value='Без входа · при необходимости добавьте cookies')
        self.option_row(content,'⌁','Доступ и подключение',self.access_caption,'Настроить',self.show_settings)
        def access_update(*_):
            browser=self.browser.get()
            mode=CONNECTIONS[self.connection.get()]
            suffix='VPN/TUN без прокси' if mode=='direct' else ('прокси включен' if self.proxy.get().strip() or mode=='custom' else 'как в Windows')
            self.access_caption.set(('Cookies: '+browser if browser!='Без cookies' else 'Без входа') + ' · ' + suffix)
        self.browser.trace_add('write',access_update)
        def proxy_update(*_):
            if self.proxy.get().strip():
                self.connection.set('Свой прокси')
            access_update()
        self.proxy.trace_add('write',proxy_update)
        self.connection.trace_add('write',access_update)
        access_update()
        self.start_button=ctk.CTkButton(content,text='Скачать видео   ↓',height=51,corner_radius=14,fg_color=GREEN,hover_color='#65ffa7',text_color='#072513',font=(FONT,16,'bold'),command=self.start)
        self.start_button.pack(fill='x',pady=(23,12))
        self.progress=Progress(content,height=4,corner_radius=2,fg_color='#26322b',progress_color=GREEN)
        self.progress.set(0)
        self.progress.pack(fill='x')
        ctk.CTkLabel(content,textvariable=self.status,text_color=MUTED,font=(FONT,11),wraplength=630,justify='center').pack(pady=(9,5))
        foot=ctk.CTkFrame(content,fg_color='transparent')
        foot.pack(fill='x',pady=(2,15))
        self.cancel_button=ctk.CTkButton(foot,text='Остановить',width=105,height=30,corner_radius=10,fg_color='transparent',border_width=1,border_color=LINE,text_color=MUTED,hover_color=FIELD,state='disabled',command=self.cancel)
        self.cancel_button.pack(side='left')
        ctk.CTkButton(foot,text='Открыть папку  ↗',width=140,height=30,fg_color='transparent',hover_color=FIELD,text_color=MUTED,command=self.open_folder).pack(side='right')
        ctk.CTkButton(foot,text='Журнал',width=80,height=30,fg_color='transparent',hover_color=FIELD,text_color=MUTED,command=self.show_log).pack(side='right',padx=5)
        ctk.CTkLabel(card,text='MKV  /  БЕЗ ПЕРЕКОДИРОВАНИЯ  /  ДО 8 ПОТОКОВ ПО УМОЛЧАНИЮ',text_color='#66736b',font=(FONT,9)).pack(pady=(0,21))
        ctk.CTkLabel(outer,text='LUMA    ·    Ваши видео остаются на вашем компьютере',text_color='#68736c',font=(FONT,10)).pack(pady=(0,20))
        # Log storage is created eagerly; the window itself opens on demand.
        self.log_window=ctk.CTkToplevel(root)
        self.log_window.title('LUMA — журнал загрузки')
        self.log_window.geometry('780x420')
        self.log_window.configure(fg_color=CARD)
        self.log=ctk.CTkTextbox(self.log_window,fg_color=BG,text_color='#bdc9c1',font=('Consolas',12),state='disabled')
        self.log.pack(fill='both',expand=True,padx=16,pady=16)
        self.log_window.protocol('WM_DELETE_WINDOW',self.log_window.withdraw)
        self.log_window.withdraw()
        root.after(100,self.poll)

    def paint_quality(self):
        for value,b in self.quality_buttons.items():
            selected=self.quality.get()==value
            b.configure(fg_color='#173626' if selected else FIELD,border_width=1,border_color='#2e8051' if selected else LINE,text_color=GREEN if selected else MUTED,hover_color='#22372a')

    def option_row(self,parent,icon,title,detail,action,command):
        frame=ctk.CTkFrame(parent,fg_color='transparent')
        frame.pack(fill='x',pady=(20,0))
        badge=ctk.CTkLabel(frame,text=icon,width=42,height=43,corner_radius=12,fg_color='#153022',text_color=GREEN,font=(FONT,23))
        badge.pack(side='left',padx=(0,12))
        labels=ctk.CTkFrame(frame,fg_color='transparent')
        labels.pack(side='left',fill='x',expand=True)
        ctk.CTkLabel(labels,text=title,font=(FONT,14,'bold'),text_color=TEXT,anchor='w').pack(fill='x')
        ctk.CTkLabel(labels,textvariable=detail,font=(FONT,11),text_color=MUTED,anchor='w',wraplength=390,justify='left').pack(fill='x')
        ctk.CTkButton(frame,text=action+'  →',width=106,height=37,corner_radius=12,border_width=1,border_color=LINE,fg_color='#1c211e',hover_color='#29332c',text_color='#ccd5cf',font=(FONT,11),command=command).pack(side='right',padx=(8,0))

    def show_log(self):
        self.log_window.deiconify()
        self.log_window.lift()

    def show_settings(self):
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.lift()
            return
        w=ctk.CTkToplevel(self.root)
        self.settings_window=w
        w.title('LUMA — доступ и подключение')
        w.geometry('600x700')
        w.minsize(530,650)
        w.configure(fg_color=CARD)
        w.transient(self.root)
        f=ctk.CTkScrollableFrame(w,fg_color=CARD)
        f.pack(fill='both',expand=True,padx=24,pady=24)
        def label(text):
            ctk.CTkLabel(f,text=text,font=(FONT,13,'bold'),text_color=TEXT).pack(anchor='w',pady=(16,7))
        ctk.CTkLabel(f,text='Доступ и подключение',font=(FONT,23,'bold'),text_color=TEXT).pack(anchor='w')
        ctk.CTkLabel(f,text='Настройки применяются к следующей загрузке.',font=(FONT,12),text_color=MUTED).pack(anchor='w',pady=(4,10))
        label('Cookies из браузера или файла')
        ctk.CTkOptionMenu(f,variable=self.browser,values=list(BROWSERS),fg_color=FIELD,button_color='#2b3b30',button_hover_color='#3a4c41',text_color=TEXT,height=39).pack(fill='x')
        row=ctk.CTkFrame(f,fg_color='transparent')
        row.pack(fill='x',pady=10)
        ctk.CTkEntry(row,textvariable=self.cookies,placeholder_text='Файл cookies.txt (Netscape)',fg_color=FIELD,border_color=LINE,height=39).pack(side='left',fill='x',expand=True)
        ctk.CTkButton(row,text='Выбрать',width=85,height=39,fg_color='#243b2d',hover_color='#31523e',command=self.pick_cookies).pack(side='right',padx=(8,0))
        ctk.CTkLabel(f,text='Войдите в YouTube в выбранном браузере. Если чтение cookies не удается, полностью закройте браузер. Для Chrome/Edge может понадобиться Firefox или файл cookies.txt.',text_color=MUTED,font=(FONT,12),wraplength=490,justify='left').pack(anchor='w')
        label('Подключение')
        ctk.CTkOptionMenu(f,variable=self.connection,values=list(CONNECTIONS),fg_color=FIELD,button_color='#2b3b30',button_hover_color='#3a4c41',text_color=TEXT,height=39).pack(fill='x')
        ctk.CTkLabel(f,text='«Как в Windows» использует системные настройки. «VPN / TUN» не использует HTTP/SOCKS-прокси и подходит для VPN на всем компьютере.',text_color=MUTED,font=(FONT,12),wraplength=490,justify='left').pack(anchor='w',pady=(8,0))
        label('Адрес своего прокси')
        self.proxy_entry=ctk.CTkEntry(f,textvariable=self.proxy,show='•',placeholder_text='socks5://127.0.0.1:1080',height=39,fg_color=FIELD,border_color=LINE)
        self.proxy_entry.pack(fill='x')
        ctk.CTkButton(f,text='Показать / скрыть',fg_color='transparent',text_color=MUTED,hover_color=FIELD,command=self.toggle_proxy).pack(anchor='w',pady=4)
        ctk.CTkLabel(f,text='Для «Свой прокси» укажите полный адрес из VPN-приложения. Пример: socks5://127.0.0.1:1080. IPv4 должен содержать четыре группы цифр.',text_color=MUTED,font=(FONT,12),wraplength=490,justify='left').pack(anchor='w')
        label('Параллельные фрагменты')
        self.stream_label=ctk.CTkLabel(f,textvariable=self.streams,text_color=GREEN,font=(FONT,15,'bold'))
        self.stream_label.pack(anchor='w')
        ctk.CTkSlider(f,from_=1,to=16,number_of_steps=15,variable=self.streams,progress_color=GREEN,button_color=GREEN,button_hover_color='#6cffa9').pack(fill='x',pady=6)
        ctk.CTkLabel(f,text='8 — рекомендуемое значение. Больше потоков не всегда означает выше скорость.',text_color=MUTED,font=(FONT,12),wraplength=490,justify='left').pack(anchor='w')
        label('Качество — полный список')
        ctk.CTkOptionMenu(f,variable=self.quality,values=list(QUALITIES),fg_color=FIELD,button_color='#2b3b30',height=36).pack(fill='x')
        ctk.CTkButton(f,text='Готово',height=43,fg_color=GREEN,hover_color='#65ffa7',text_color='#072513',font=(FONT,14,'bold'),command=w.destroy).pack(fill='x',pady=(22,8))


if __name__=='__main__':
    ctk.set_appearance_mode('dark')
    ctk.set_default_color_theme('green')
    window=ctk.CTk()
    App(window)
    window.mainloop()
