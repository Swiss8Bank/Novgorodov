﻿param([switch]$Update)
$ErrorActionPreference = 'Stop'
$OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new()
Set-Location -LiteralPath $PSScriptRoot

function Refresh-Path {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + $env:Path
}
function Install-Package([string]$Id) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw 'Не найден winget. Установите «Установщик приложений» из Microsoft Store и повторите запуск. Либо установите компоненты по README.txt.'
    }
    Write-Host "Установка компонента: $Id" -ForegroundColor Green
    & winget install --id $Id --exact --source winget --accept-source-agreements --accept-package-agreements --disable-interactivity
    if ($LASTEXITCODE -ne 0) {
        throw "Не удалось установить $Id. Проверьте интернет/VPN. Инструкция: README.txt. Код: $LASTEXITCODE"
    }
    Refresh-Path
}
function Find-Python {
    $candidates = @('py', 'python', "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe")
    foreach ($candidate in $candidates) {
        if (-not (Get-Command $candidate -ErrorAction SilentlyContinue)) { continue }
        try {
            $pythonArguments = @('-c', 'import sys; assert sys.version_info >= (3, 11); print(sys.executable)')
            if ($candidate -eq 'py') { $pythonArguments = @('-3') + $pythonArguments }
            $found = & $candidate @pythonArguments 2>$null
            if ($LASTEXITCODE -eq 0 -and $found) { return ([string]($found | Select-Object -Last 1)).Trim() }
        } catch { }
    }
    return $null
}
try {
    Write-Host ''
    Write-Host 'LUMA / YouTube Downloader' -ForegroundColor Green
    Write-Host 'При первом запуске устанавливаются Python, FFmpeg, Deno и библиотеки.'
    Write-Host 'Последующие запуски работают без повторной установки.'
    Refresh-Path
    $python = Find-Python
    if (-not $python) {
        Install-Package 'Python.Python.3.12'
        $python = Find-Python
        if (-not $python) { throw 'Python установлен, но еще недоступен. Перезапустите START.bat.' }
    }
    if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { Install-Package 'Gyan.FFmpeg' }
    if (-not (Get-Command deno -ErrorAction SilentlyContinue)) { Install-Package 'DenoLand.Deno' }
    if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { throw 'FFmpeg пока не виден в PATH. Перезапустите START.bat.' }
    if (-not (Get-Command deno -ErrorAction SilentlyContinue)) { throw 'Deno пока не виден в PATH. Перезапустите START.bat.' }
    $venvPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $venvPython)) {
        & $python -m venv (Join-Path $PSScriptRoot '.venv')
        if ($LASTEXITCODE -ne 0) { throw 'Не удалось создать окружение Python. Распакуйте программу в доступную для записи папку.' }
    }
    $requirements = Join-Path $PSScriptRoot 'requirements.txt'
    $hash = (Get-FileHash -LiteralPath $requirements -Algorithm SHA256).Hash
    $ready = Join-Path $PSScriptRoot '.ready'
    $saved = if (Test-Path -LiteralPath $ready) { (Get-Content -LiteralPath $ready -Raw).Trim() } else { '' }
    & $venvPython -c "import importlib.util,sys;sys.exit(0 if all(importlib.util.find_spec(m) for m in ('customtkinter','PIL','yt_dlp')) else 1)"
    $dependenciesOK = $LASTEXITCODE -eq 0
    if ($saved -ne $hash -or -not $dependenciesOK) {
        Write-Host 'Установка библиотек интерфейса и загрузчика...' -ForegroundColor Green
        & $venvPython -m pip install --disable-pip-version-check -r $requirements
        if ($LASTEXITCODE -ne 0) { throw 'Ошибка установки библиотек. Проверьте доступ к pypi.org через VPN и повторите запуск.' }
        Set-Content -LiteralPath $ready -Value $hash -Encoding ASCII
    }
    if ($Update) {
        & $venvPython -m pip install --upgrade 'yt-dlp[default]'
        if ($LASTEXITCODE -ne 0) { throw 'Обновление yt-dlp не удалось. Проверьте интернет и повторите UPDATE.bat.' }
    }
    & $venvPython -c 'import tkinter; print("Компоненты готовы. Запуск LUMA...")'
    if ($LASTEXITCODE -ne 0) { throw 'Python установлен без Tkinter. Установите Python с компонентом Tcl/Tk.' }
    & $venvPython (Join-Path $PSScriptRoot 'app.py')
    if ($LASTEXITCODE -ne 0) { throw "Программа завершилась с ошибкой $LASTEXITCODE. Сообщение показано выше." }
} catch {
    Write-Host ''
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
