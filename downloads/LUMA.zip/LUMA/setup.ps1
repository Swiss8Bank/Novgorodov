﻿param([switch]$Update, [switch]$RepairTk, [switch]$LibraryOnly)
$ErrorActionPreference = 'Stop'
$OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new()
$probeFile = Join-Path $PSScriptRoot 'bootstrap_probe.py'

function Refresh-Path {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + $env:Path
}
function Quote-NativeArgument([string]$Value) {
    # Quote one Windows argv element, including embedded quotes and trailing slashes.
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    return '"' + $escaped + '"'
}
function Invoke-Native([string]$Executable, [string[]]$Arguments) {
    $commandLine = ($Arguments | ForEach-Object { Quote-NativeArgument $_ }) -join ' '
    $process = Start-Process -FilePath $Executable -ArgumentList $commandLine -Wait -NoNewWindow -PassThru
    return $process.ExitCode
}
function Invoke-Probe([string]$Executable, [string]$Mode, [string[]]$Prefix = @()) {
    $logRoot = Join-Path ([IO.Path]::GetTempPath()) ('luma-check-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $logRoot | Out-Null
    try {
        $probeArguments = @($Prefix) + @('-X', 'utf8', $probeFile, $Mode)
        $commandLine = ($probeArguments | ForEach-Object { Quote-NativeArgument $_ }) -join ' '
        $stdout = Join-Path $logRoot 'stdout.txt'
        $stderr = Join-Path $logRoot 'stderr.txt'
        $process = Start-Process -FilePath $Executable -ArgumentList $commandLine -Wait -NoNewWindow -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        $outText = if (Test-Path -LiteralPath $stdout) { [IO.File]::ReadAllText($stdout, [Text.Encoding]::UTF8).Trim() } else { '' }
        $errText = if (Test-Path -LiteralPath $stderr) { [IO.File]::ReadAllText($stderr, [Text.Encoding]::UTF8).Trim() } else { '' }
        return [pscustomobject]@{ OK = ($process.ExitCode -eq 0); Code = $process.ExitCode; Output = $outText; Error = $errText }
    } catch {
        return [pscustomobject]@{ OK = $false; Code = -1; Output = ''; Error = $_.Exception.Message }
    } finally {
        Remove-Item -LiteralPath $logRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
function Install-Package([string]$Id) {
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) { throw 'Не найден winget. Установите «Установщик приложений» из Microsoft Store. Инструкция: README.txt.' }
    Write-Host "Установка компонента: $Id" -ForegroundColor Green
    $code = Invoke-Native $winget.Source @('install', '--id', $Id, '--exact', '--source', 'winget', '--accept-source-agreements', '--accept-package-agreements', '--disable-interactivity')
    if ($code -ne 0) { throw "Не удалось установить $Id. Проверьте интернет/VPN. Код: $code" }
    Refresh-Path
}
function Find-PythonWithTk {
    $candidateSpecs = @(
        @{ Name = "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe"; Prefix = @() },
        @{ Name = "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"; Prefix = @() },
        @{ Name = 'py'; Prefix = @('-3.13') },
        @{ Name = 'py'; Prefix = @('-3.12') },
        @{ Name = 'py'; Prefix = @('-3') },
        @{ Name = 'python'; Prefix = @() }
    )
    $checked = @{}
    foreach ($spec in $candidateSpecs) {
        $command = Get-Command $spec.Name -ErrorAction SilentlyContinue
        if (-not $command) { continue }
        $versionCheck = Invoke-Probe -Executable $command.Source -Mode 'version' -Prefix $spec.Prefix
        if (-not $versionCheck.OK) { continue }
        $pythonPath = $versionCheck.Output.Trim()
        if (-not (Test-Path -LiteralPath $pythonPath) -or $checked.ContainsKey($pythonPath)) { continue }
        $checked[$pythonPath] = $true
        $tkCheck = Invoke-Probe -Executable $pythonPath -Mode 'tk'
        if ($tkCheck.OK) { return $pythonPath }
        Write-Host "Tcl/Tk недоступен в $pythonPath" -ForegroundColor Yellow
        if ($tkCheck.Output) { Write-Host $tkCheck.Output }
        if ($tkCheck.Error) { Write-Host $tkCheck.Error }
    }
    return $null
}
function Install-PythonWithTk {
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) { throw 'Для восстановления Python нужен winget («Установщик приложений» Microsoft Store). Альтернатива: установщик Python → Modify → tcl/tk and IDLE.' }
    Write-Host 'Подготовка официального Python 3.13 с Tcl/Tk...' -ForegroundColor Green
    $cache = Join-Path ([IO.Path]::GetTempPath()) ('luma-python-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $cache | Out-Null
    try {
        # winget checks the manifest's installer hash; Windows signature is checked too.
        $code = Invoke-Native $winget.Source @('download', '--id', 'Python.Python.3.13', '--exact', '--source', 'winget', '--architecture', 'x64', '--download-directory', $cache, '--skip-dependencies', '--accept-source-agreements', '--accept-package-agreements', '--disable-interactivity')
        if ($code -ne 0) { throw "Не удалось скачать Python (код $code). Обновите winget и проверьте VPN. Альтернатива: установщик Python → Modify → tcl/tk and IDLE." }
        $installer = $null
        foreach ($candidate in (Get-ChildItem -LiteralPath $cache -Filter '*.exe' -File -Recurse)) {
            if ($candidate.Name -match '(?i)launcher') { continue }
            $signature = Get-AuthenticodeSignature -LiteralPath $candidate.FullName
            if ($signature.Status -eq 'Valid' -and $signature.SignerCertificate.Subject -match 'Python Software Foundation') {
                $installer = $candidate.FullName
                break
            }
        }
        if (-not $installer) { throw 'Подпись Python Software Foundation не подтверждена. Установка остановлена; проверьте дату Windows и обновления сертификатов.' }
        # The official installer enters Modify automatically when already installed.
        # Explicit Include_tcltk=1 adds the missing feature; no system Python is removed.
        $code = Invoke-Native $installer @('/quiet', '/norestart', 'InstallAllUsers=0', 'Include_tcltk=1', 'Include_pip=1', 'InstallLauncherAllUsers=0')
        if ($code -notin @(0, 3010)) { throw "Ошибка установки Tcl/Tk, код $code. Запустите установщик Python вручную: Modify → tcl/tk and IDLE." }
        Refresh-Path
    } finally {
        Remove-Item -LiteralPath $cache -Recurse -Force -ErrorAction SilentlyContinue
    }
}
if ($LibraryOnly) { return }
try {
    Set-Location -LiteralPath $PSScriptRoot
    Write-Host ''
    Write-Host 'LUMA 1.2 / YouTube Downloader' -ForegroundColor Green
    Write-Host 'Проверка Python, Tcl/Tk и компонентов...'
    if (-not (Test-Path -LiteralPath $probeFile)) { throw 'Файл bootstrap_probe.py не найден. Распакуйте весь новый архив в отдельную папку.' }
    Refresh-Path
    $venvFolder = Join-Path $PSScriptRoot '.venv'
    $venvPython = Join-Path $venvFolder 'Scripts\python.exe'
    $venvOK = $false
    if ((Test-Path -LiteralPath $venvPython) -and -not $RepairTk) {
        $versionCheck = Invoke-Probe -Executable $venvPython -Mode 'version'
        $tkCheck = Invoke-Probe -Executable $venvPython -Mode 'tk'
        $venvOK = $versionCheck.OK -and $tkCheck.OK
        if (-not $venvOK) {
            Write-Host 'Локальное окружение требует восстановления.' -ForegroundColor Yellow
            Write-Host ($tkCheck.Output + ' ' + $tkCheck.Error)
        }
    }
    if (-not $venvOK) {
        $python = if ($RepairTk) { $null } else { Find-PythonWithTk }
        if (-not $python) {
            Install-PythonWithTk
            $python = Find-PythonWithTk
        }
        if (-not $python) { throw 'Python установлен, но Tcl/Tk пока не запускается. Закройте консоль и повторите START.bat. Если ошибка повторяется, пришлите строки диагностики выше.' }
        if (Test-Path -LiteralPath $venvFolder) {
            # Preserve the previous app environment instead of deleting it.
            $backup = Join-Path $PSScriptRoot ('.venv.backup-' + [Guid]::NewGuid().ToString('N'))
            Move-Item -LiteralPath $venvFolder -Destination $backup
            Write-Host "Предыдущее окружение сохранено: $backup"
        }
        $code = Invoke-Native $python @('-m', 'venv', $venvFolder)
        if ($code -ne 0) { throw 'Не удалось создать окружение. Распакуйте программу в доступную для записи папку.' }
        $tkCheck = Invoke-Probe -Executable $venvPython -Mode 'tk'
        if (-not $tkCheck.OK) { throw ('Ошибка Tcl/Tk в новом окружении: ' + $tkCheck.Output + ' ' + $tkCheck.Error) }
    }
    if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { Install-Package 'Gyan.FFmpeg' }
    if (-not (Get-Command deno -ErrorAction SilentlyContinue)) { Install-Package 'DenoLand.Deno' }
    if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { throw 'FFmpeg установлен, но пока не виден в PATH. Перезапустите START.bat.' }
    if (-not (Get-Command deno -ErrorAction SilentlyContinue)) { throw 'Deno установлен, но пока не виден в PATH. Перезапустите START.bat.' }
    $requirements = Join-Path $PSScriptRoot 'requirements.txt'
    $hash = (Get-FileHash -LiteralPath $requirements -Algorithm SHA256).Hash
    $ready = Join-Path $PSScriptRoot '.ready'
    $saved = if (Test-Path -LiteralPath $ready) { (Get-Content -LiteralPath $ready -Raw).Trim() } else { '' }
    $dependencyCheck = Invoke-Probe -Executable $venvPython -Mode 'deps'
    if ($saved -ne $hash -or -not $dependencyCheck.OK) {
        Write-Host 'Установка библиотек...' -ForegroundColor Green
        $code = Invoke-Native $venvPython @('-m', 'pip', 'install', '--disable-pip-version-check', '-r', $requirements)
        if ($code -ne 0) { throw 'Ошибка установки библиотек. Проверьте доступ к pypi.org через VPN.' }
        Set-Content -LiteralPath $ready -Value $hash -Encoding ASCII
    }
    if ($Update) {
        $code = Invoke-Native $venvPython @('-m', 'pip', 'install', '--upgrade', 'yt-dlp[default]')
        if ($code -ne 0) { throw 'Обновление yt-dlp не удалось. Проверьте интернет и повторите UPDATE.bat.' }
    }
    Write-Host 'Компоненты готовы. Запуск LUMA...' -ForegroundColor Green
    $code = Invoke-Native $venvPython @((Join-Path $PSScriptRoot 'app.py'))
    if ($code -ne 0) { throw "Программа завершилась с ошибкой $code. Сообщение показано выше." }
} catch {
    Write-Host ''
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
