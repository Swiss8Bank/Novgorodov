@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -RepairTk
if errorlevel 1 (
 echo.
 echo Восстановление не завершено. Диагностика показана выше.
 pause
 exit /b 1
)
endlocal
