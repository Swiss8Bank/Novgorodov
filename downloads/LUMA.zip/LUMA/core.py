"""Download engine. No browser data or proxy passwords are saved to settings."""
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading

QUALITIES = ('360', '480', '720', '1080', '1440', '2160', 'Максимальное')
BROWSERS = {'Без cookies': None, 'Chrome': 'chrome', 'Firefox': 'firefox', 'Edge': 'edge', 'Файл cookies.txt': 'file'}


@dataclass(frozen=True)
class Settings:
    url: str
    folder: str
    quality: str = '1080'
    streams: int = 8
    browser: str = 'Без cookies'
    cookies: str = ''
    proxy: str = ''

    def validate(self):
        u = urlsplit(self.url)
        if u.scheme not in ('https', 'http') or u.hostname not in (
            'youtube.com', 'www.youtube.com', 'm.youtube.com',
            'music.youtube.com', 'youtu.be', 'www.youtu.be',
        ) or u.username or u.password:
            raise ValueError('Укажите ссылку на видео с youtube.com или youtu.be.')
        if self.quality not in QUALITIES:
            raise ValueError('Выберите качество из списка.')
        if not 1 <= self.streams <= 16:
            raise ValueError('Количество потоков: от 1 до 16.')
        if self.browser not in BROWSERS:
            raise ValueError('Неверный источник cookies.')
        if not self.folder.strip():
            raise ValueError('Укажите папку сохранения.')
        if self.browser == 'Файл cookies.txt':
            if not self.cookies or not Path(self.cookies).is_file():
                raise ValueError('Выберите существующий файл cookies.txt в формате Netscape.')
        if self.proxy:
            p = urlsplit(self.proxy)
            if p.scheme not in ('http', 'https', 'socks5', 'socks5h', 'socks4') or not p.hostname:
                raise ValueError('Прокси: http://адрес:порт или socks5://адрес:порт.')
            try:
                p.port
            except ValueError:
                raise ValueError('Неверный порт прокси.') from None


def build_command(settings, cookie_copy=None, check_tools=True):
    settings.validate()
    if check_tools and not shutil.which('ffmpeg'):
        raise RuntimeError('Не найден FFmpeg. Закройте окно и запустите START.bat для установки компонентов.')
    runtimes = [r for r in ('deno', 'node') if shutil.which(r)]
    if check_tools and not runtimes:
        raise RuntimeError('Не найден Deno или Node.js. Запустите START.bat для установки Deno.')
    fmt = 'bv*+ba/b' if settings.quality == 'Максимальное' else (
        f'bv*[height<={settings.quality}]+ba/b[height<={settings.quality}]'
    )
    cmd = [sys.executable, '-u', '-m', 'yt_dlp', '--ignore-config',
           '--no-playlist', '--newline', '--no-colors', '--progress',
           '--progress-template', 'download:PROGRESS|%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s',
           '--format', fmt, '--merge-output-format', 'mkv',
           '--concurrent-fragments', str(settings.streams),
           '--retries', '8', '--fragment-retries', '8',
           '--extractor-retries', '3', '--socket-timeout', '30',
           '--continue', '--no-overwrites', '--no-mtime',
           '--paths', str(Path(settings.folder).expanduser().resolve()),
           '--output', '%(title).150B [%(id)s].%(ext)s']
    if os.name == 'nt':
        cmd.append('--windows-filenames')
    for runtime in runtimes:
        cmd += ['--js-runtimes', runtime]
    if settings.browser == 'Файл cookies.txt':
        cmd += ['--cookies', str(cookie_copy or settings.cookies)]
    elif BROWSERS[settings.browser]:
        cmd += ['--cookies-from-browser', BROWSERS[settings.browser]]
    if settings.proxy:
        cmd += ['--proxy', settings.proxy]
    return cmd + ['--', settings.url]


def redact(message, proxy=''):
    if proxy:
        message = message.replace(proxy, '[прокси]')
    return re.sub(r'(?i)(https?|socks[45]h?)://[^\s/@]+:[^\s/@]+@', r'\1://***@', message)


class Downloader:
    def __init__(self, emit):
        self.emit = emit
        self.cancelled = threading.Event()
        self.process = None
        self.lock = threading.Lock()

    def cancel(self):
        self.cancelled.set()
        with self.lock:
            process = self.process
        if process is not None:
            self._stop(process)

    @staticmethod
    def _stop(process):
        if process.poll() is not None:
            return
        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               creationflags=subprocess.CREATE_NO_WINDOW)
            else:
                os.killpg(process.pid, signal.SIGTERM)
        except (OSError, ProcessLookupError):
            pass

    def run(self, settings):
        try:
            settings.validate()
            folder = Path(settings.folder).expanduser()
            folder.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryDirectory(prefix='yt-downloader-') as temp:
                cookie_copy = None
                if settings.browser == 'Файл cookies.txt':
                    cookie_copy = Path(temp) / 'cookies.txt'
                    shutil.copyfile(settings.cookies, cookie_copy)
                    cookie_copy.chmod(0o600)
                cmd = build_command(settings, cookie_copy)
                if self.cancelled.is_set():
                    self.emit('cancelled', None)
                    return
                self.emit('log', 'Чтение информации о видео…')
                kwargs = {'stdout': subprocess.PIPE, 'stderr': subprocess.STDOUT,
                          'text': True, 'encoding': 'utf-8', 'errors': 'replace',
                          'env': {**os.environ, 'PYTHONIOENCODING': 'utf-8'}}
                if os.name == 'nt':
                    kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
                else:
                    kwargs['start_new_session'] = True
                process = subprocess.Popen(cmd, **kwargs)
                with self.lock:
                    self.process = process
                # Handle cancellation between the pre-start check and Popen.
                if self.cancelled.is_set():
                    self._stop(process)
                tail = []
                for line in process.stdout:
                    line = redact(line.rstrip(), settings.proxy)
                    if line.startswith('PROGRESS|'):
                        fields = line.split('|')
                        if len(fields) >= 4:
                            try:
                                percent = float(fields[1].strip().rstrip('%'))
                            except ValueError:
                                percent = None
                            self.emit('progress', (percent, f'{fields[1].strip()}  •  {fields[2].strip()}  •  осталось {fields[3].strip()}'))
                    elif line:
                        tail.append(line)
                        tail = tail[-8:]
                        self.emit('log', line)
                code = process.wait()
                if self.cancelled.is_set():
                    self.emit('cancelled', None)
                elif code:
                    raise RuntimeError('\n'.join(tail[-4:]) or f'Загрузка завершилась с кодом {code}.')
                else:
                    self.emit('success', str(folder.resolve()))
        except Exception as error:
            if self.cancelled.is_set():
                self.emit('cancelled', None)
            else:
                self.emit('error', redact(str(error), settings.proxy))
        finally:
            with self.lock:
                self.process = None
