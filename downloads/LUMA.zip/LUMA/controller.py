"""YouTube Downloader — local desktop UI."""
import importlib.util
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
from core import BROWSERS, QUALITIES, Downloader, Settings, CONNECTIONS, error_hint

CONFIG = Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'SimpleYouTubeDownloader' / 'settings.json'


class App:
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.downloader = None
        self.closing = False
        self.last_progress = 0
        root.title('YouTube Downloader — загрузка видео')
        root.geometry('850x740')
        root.minsize(760, 680)
        root.protocol('WM_DELETE_WINDOW', self.close)
        saved = {}
        try:
            saved = json.loads(CONFIG.read_text(encoding='utf-8'))
            if not isinstance(saved, dict):
                saved = {}
        except (OSError, ValueError):
            pass
        self.url = tk.StringVar()
        self.folder = tk.StringVar(value=str(saved.get('folder', Path.home() / 'Downloads' / 'YouTube')))
        self.quality = tk.StringVar(value=saved.get('quality', '1080'))
        if self.quality.get() not in QUALITIES:
            self.quality.set('1080')
        self.browser = tk.StringVar(value='Без cookies')
        self.cookies = tk.StringVar()
        self.proxy = tk.StringVar()
        self.streams = tk.IntVar(value=8)
        self.status = tk.StringVar(value='Вставьте ссылку на видео. VPN включается отдельно.')
        self.proxy_visible = False
        f = ttk.Frame(root, padding=18)
        f.pack(fill='both', expand=True)
        f.columnconfigure(1, weight=1)
        ttk.Label(f, text='Загрузить видео с YouTube', font=('Segoe UI', 19, 'bold')).grid(row=0, column=0, columnspan=3, sticky='w', pady=(0, 12))
        self.entry(f, 1, 'Ссылка на видео', self.url)
        ttk.Button(f, text='Вставить', command=self.paste).grid(row=1, column=2, padx=6)
        ttk.Label(f, text='Качество до').grid(row=2, column=0, sticky='w', pady=7)
        ttk.Combobox(f, textvariable=self.quality, values=QUALITIES, state='readonly', width=20).grid(row=2, column=1, sticky='w')
        self.entry(f, 3, 'Папка сохранения', self.folder)
        ttk.Button(f, text='Выбрать', command=self.pick_folder).grid(row=3, column=2, padx=6)
        ttk.Label(f, text='Cookies').grid(row=4, column=0, sticky='w', pady=7)
        ttk.Combobox(f, textvariable=self.browser, values=list(BROWSERS), state='readonly', width=24).grid(row=4, column=1, sticky='w')
        self.entry(f, 5, 'Файл cookies.txt', self.cookies)
        ttk.Button(f, text='Выбрать', command=self.pick_cookies).grid(row=5, column=2, padx=6)
        ttk.Label(f, text='Если YouTube просит вход: выберите браузер с вашим аккаунтом или cookies.txt.\nПри ошибке чтения Chrome/Edge закройте браузер; если не помогло — Firefox или файл.', wraplength=790).grid(row=6, column=0, columnspan=3, sticky='w', pady=(2, 9))
        self.proxy_entry = self.entry(f, 7, 'Прокси (необязательно)', self.proxy, show='•')
        ttk.Button(f, text='Показать', command=self.toggle_proxy).grid(row=7, column=2, padx=6)
        ttk.Label(f, text='С обычным VPN оставьте поле пустым. Пример: socks5://127.0.0.1:1080', wraplength=780).grid(row=8, column=0, columnspan=3, sticky='w', pady=(0, 8))
        ttk.Label(f, text='Параллельных фрагментов').grid(row=9, column=0, sticky='w')
        ttk.Spinbox(f, from_=1, to=16, textvariable=self.streams, width=8).grid(row=9, column=1, sticky='w')
        controls = ttk.Frame(f)
        controls.grid(row=10, column=0, columnspan=3, sticky='ew', pady=14)
        self.start_button = ttk.Button(controls, text='Скачать', command=self.start)
        self.start_button.pack(side='left', ipadx=20)
        self.cancel_button = ttk.Button(controls, text='Остановить', state='disabled', command=self.cancel)
        self.cancel_button.pack(side='left', padx=8)
        ttk.Button(controls, text='Открыть папку', command=self.open_folder).pack(side='left')
        self.progress = ttk.Progressbar(f, maximum=100)
        self.progress.grid(row=11, column=0, columnspan=3, sticky='ew')
        ttk.Label(f, textvariable=self.status, wraplength=780).grid(row=12, column=0, columnspan=3, sticky='w', pady=8)
        self.log = ScrolledText(f, height=10, wrap='word', font=('Consolas', 10), state='disabled')
        self.log.grid(row=13, column=0, columnspan=3, sticky='nsew')
        f.rowconfigure(13, weight=1)
        ttk.Label(f, text='MKV • без перекодирования • продолжение незавершенной загрузки\nПароли прокси и cookies не сохраняются в настройках программы.', wraplength=780).grid(row=14, column=0, columnspan=3, sticky='w', pady=(9, 0))
        root.after(100, self.poll)

    @staticmethod
    def entry(frame, row, label, var, **kwargs):
        ttk.Label(frame, text=label).grid(row=row, column=0, sticky='w', pady=7, padx=(0, 12))
        widget = ttk.Entry(frame, textvariable=var, **kwargs)
        widget.grid(row=row, column=1, sticky='ew')
        return widget

    def paste(self):
        try:
            self.url.set(self.root.clipboard_get().strip())
        except tk.TclError:
            pass

    def toggle_proxy(self):
        self.proxy_visible = not self.proxy_visible
        self.proxy_entry.configure(show='' if self.proxy_visible else '•')

    def pick_folder(self):
        path = filedialog.askdirectory()
        if path:
            self.folder.set(path)

    def pick_cookies(self):
        path = filedialog.askopenfilename(filetypes=[('Cookies Netscape', '*.txt'), ('Все файлы', '*.*')])
        if path:
            self.cookies.set(path)
            self.browser.set('Файл cookies.txt')

    def open_folder(self):
        try:
            folder = Path(self.folder.get()).expanduser()
            folder.mkdir(parents=True, exist_ok=True)
            if os.name == 'nt':
                os.startfile(str(folder.resolve()))
            else:
                subprocess.Popen(['open' if sys.platform == 'darwin' else 'xdg-open', str(folder.resolve())])
        except Exception as error:
            messagebox.showerror('Папка', str(error))

    def emit(self, kind, value):
        if kind == 'progress':
            now = time.monotonic()
            if now - self.last_progress < 0.25:
                return
            self.last_progress = now
        self.events.put((kind, value))

    def start(self):
        if self.downloader:
            return
        try:
            if importlib.util.find_spec('yt_dlp') is None:
                raise RuntimeError('Не установлен yt-dlp. Запустите START.bat.')
            settings = Settings(self.url.get().strip(), self.folder.get().strip(), self.quality.get(),
                                int(self.streams.get()), self.browser.get(), self.cookies.get().strip(), self.proxy.get().strip(),
                                CONNECTIONS[self.connection.get()] if hasattr(self, 'connection') else 'auto')
            settings.validate()
            CONFIG.parent.mkdir(parents=True, exist_ok=True)
            CONFIG.write_text(json.dumps({'folder': settings.folder, 'quality': settings.quality, 'connection': settings.connection}, ensure_ascii=False), encoding='utf-8')
        except Exception as error:
            messagebox.showerror('Проверьте настройки', str(error))
            return
        self.progress['value'] = 0
        self.start_button.configure(state='disabled')
        self.cancel_button.configure(state='normal')
        self.status.set('Подготовка и получение информации…')
        self.downloader = Downloader(self.emit)
        threading.Thread(target=self.downloader.run, args=(settings,), daemon=True).start()

    def cancel(self):
        if self.downloader:
            self.cancel_button.configure(state='disabled')
            self.status.set('Остановка…')
            threading.Thread(target=self.downloader.cancel, daemon=True).start()

    def close(self):
        if self.downloader:
            if not messagebox.askyesno('Закрыть', 'Остановить загрузку и закрыть программу?'):
                return
            self.closing = True
            self.cancel()
        else:
            self.root.destroy()

    def poll(self):
        try:
            # Bound each batch so verbose logs never freeze the window.
            for _ in range(100):
                kind, value = self.events.get_nowait()
                if kind == 'progress':
                    percent, text = value
                    if percent is not None:
                        self.progress['value'] = percent
                    self.status.set(text)
                elif kind == 'log':
                    self.log.configure(state='normal')
                    self.log.insert('end', value + '\n')
                    if int(self.log.index('end-1c').split('.')[0]) > 600:
                        self.log.delete('1.0', '101.0')
                    self.log.see('end')
                    self.log.configure(state='disabled')
                elif kind in ('success', 'error', 'cancelled'):
                    self.downloader = None
                    self.start_button.configure(state='normal')
                    self.cancel_button.configure(state='disabled')
                    if self.closing:
                        self.root.destroy()
                        return
                    if kind == 'success':
                        self.progress['value'] = 100
                        self.status.set('Готово. Видео сохранено в папке загрузки.')
                        messagebox.showinfo('Готово', 'Видео сохранено:\n' + value)
                    elif kind == 'cancelled':
                        self.status.set('Остановлено. Для продолжения скачайте ту же ссылку с теми же настройками.')
                    else:
                        self.status.set('Ошибка. Проверьте VPN, cookies и сообщения ниже.')
                        messagebox.showerror('Не удалось скачать', value + '\n\n' + error_hint(value))
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

